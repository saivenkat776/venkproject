 CREATE TABLE work_details(workName varchar2(20),
 address varchar2(20),
 phone_number varchar2(20),
 wage_date date,
 wage_amount number);



 CREATE SEQUENCE workId_sequence START WITH 1000 increment by 1;