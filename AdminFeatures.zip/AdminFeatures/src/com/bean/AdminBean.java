package com.bean;

import java.util.Date;

public class AdminBean
{
	private String workId;
	private String workName;
	private String phoneNumber;
	private String address;
	private double wageAmount;
	private Date wageDate;
	public String getWorkId() {
		return workId;
	}
	public String getWorkName() {
		return workName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public double getWageAmount() {
		return wageAmount;
	}
	public Date getWageDate() {
		return wageDate;
	}
	public void setWorkId(String workId) {
		this.workId = workId;
	}
	public void setWorkName(String workName) {
		this.workName = workName;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setWageAmount(double wageAmount) {
		this.wageAmount = wageAmount;
	}
	public void setWageDate(Date wageDate) {
		this.wageDate = wageDate;
	}
	
	
	
  
}
