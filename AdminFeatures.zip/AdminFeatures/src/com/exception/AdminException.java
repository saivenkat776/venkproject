package com.exception;

public class AdminException {

}
