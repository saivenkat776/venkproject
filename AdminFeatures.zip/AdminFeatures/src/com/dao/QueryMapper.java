package com.dao;

public interface QueryMapper {

	public static final String RETRIVE_ALL_QUERY="SELECT workName,address,phone_number,wage_date,wage_amount FROM work_detail";
	public static final String VIEW_DONAR_DETAILS_QUERY="SELECT workName,address,phone_number,wage_date,wage_amount FROM work_detail WHERE  work_id=?";
	public static final String INSERT_QUERY="INSERT INTO work_detail VALUES(workIdsequence.NEXTVAL,?,?,?,SYSDATE,?)";
	public static final String DONARID_QUERY_SEQUENCE="SELECT workId_sequence.NEXTVAL FROM DUAL";
	
}
