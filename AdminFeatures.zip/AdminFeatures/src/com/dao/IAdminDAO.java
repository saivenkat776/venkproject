package com.dao;

import java.util.List;

import com.bean.AdminBean;

public interface IAdminDAO
{
	public String addDetails(AdminBean bean) ;
	public AdminBean viewDetails(int workid) ;
	public List<AdminBean> retriveAll();
}
