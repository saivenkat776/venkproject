package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.bean.AdminBean;

import com.util.DBConnection;


public class AdminDAO implements IAdminDAO 
{

	@Override
	public String addDetails(AdminBean bean) 
	
	{
		
       Connection connection = DBConnection.getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String workId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
        
			preparedStatement.setString(1,bean.getWorkName());
			preparedStatement.setString(2,bean.getAddress());
			preparedStatement.setString(3,bean.getPhoneNumber());
			preparedStatement.setDouble(4,bean.getWageAmount());
			
			queryResult=preparedStatement.executeUpdate();
			if(queryResult==1)
			{
				System.out.println("Successfully inserted "+queryResult+" row ");
			}
			else
			{
				System.out.println("--------Unable to insert into DB-----------");
			}
		
			preparedStatement = connection.prepareStatement(QueryMapper.DONARID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				workId=resultSet.getString(1);
				System.out.println("Work Id :"+workId);
			}
			return workId;
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			return null;
		}
		
		
	}

	@Override
	public AdminBean viewDetails(int workid) 
	{
      Connection connection=DBConnection.getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		AdminBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DONAR_DETAILS_QUERY);
			preparedStatement.setLong(1,workid);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new AdminBean();
				
				bean.setWorkName(resultset.getString(1));
				bean.setAddress(resultset.getString(2));
				bean.setPhoneNumber(resultset.getString(3));
				bean.setWageDate(resultset.getDate(4));
				bean.setWageAmount(resultset.getDouble(5));
				
				if (bean != null) {
					System.out.println("Name             :"
							+ bean.getWorkName());
					System.out.println("Address          :"
							+ bean.getAddress());
					System.out.println("Phone Number     :"
							+ bean.getPhoneNumber());
					System.out.println("Donor Date       :"
							+ bean.getWageDate());
					System.out.println("Donation Amount  :"
							+ bean.getWageAmount());
				} else {
					System.err
							.println("There are no donation details associated with donor id "
									+ workid);
				}

				
			}
			/*if( bean != null)
			{
				//logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				//logger.info("Record Not Found Successfully");
				return null;
			}*/
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return bean;
		
	}

	@Override
	public List<AdminBean> retriveAll()
	{
		Connection con=DBConnection.getConnection();
		int workCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<AdminBean> workList=new ArrayList<AdminBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				AdminBean bean=new AdminBean();
				bean.setWorkName(resultset.getString(1));
				bean.setAddress(resultset.getString(2));
				bean.setPhoneNumber(resultset.getString(3));
				bean.setWageDate(resultset.getDate(4));
				bean.setWageAmount(resultset.getDouble(5));
				workList.add(bean);
				
				workCount++;
				  
			}	
			
		}
		catch (SQLException sqlException)
		{
			System.out.println(sqlException);
		}
		return workList;
	}

}
