package com.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.bean.AdminBean;
import com.service.AdminService;

public class AdminMAIN 
{
	static AdminService service=new AdminService();
    static AdminBean bean=new AdminBean();	

	public static void main(String args[])
	{  String workId = null;
		System.out.println(" -----------------------> ADMIN OPERATIONS PAGE <------------------------ ");
		
		
		Scanner sc=new Scanner(System.in);
		
		
		while(true)
		{ System.out.println("-------------------------------------------------------------------------");
			System.out.println(" ");
		    System.out.println("***************** Select operations ******************* ");
		    System.out.println(" ");

			System.out.println("\n 1.Add Details"
					+ "\n 2.VIEW Details"
					+ "\n 3.UPDATE Details "
					+ "\n 4.EXIT");
			
			int select=sc.nextInt();
			switch(select)
			{
			case 1: {
				Scanner s=new Scanner(System.in) ;
			    Scanner sc1=new Scanner(System.in) ;
				System.out.println("\n Enter Details");

				System.out.println("Enter worker name: ");
				bean.setWorkName(sc1.nextLine());
				System.out.println("Enter worker contact: ");
				bean.setPhoneNumber(sc1.nextLine());

				System.out.println("Enter worker address: ");
				bean.setAddress(sc1.nextLine());

				System.out.println("Enter wage amount: ");
					bean.setWageAmount(s.nextDouble());
	//-----------------Add details is called -->AdminService ----------------------------
				
				      service.addDetails(bean);
				  	
					
				      break;
		        	}
			
			case 2:{ 
				      System.out.println("Enter the workID of WORKER to View :");
				      int workid=sc.nextInt();
				     bean = service.viewDetails(workid);
				    

				      break;
			         }
			
			case 3:{  
				     List<AdminBean> workList = new ArrayList<AdminBean>();
		            	
			         workList= service.retriveAll();
			         
			       /*  if (workList != null) {
							Iterator<AdminBean> i = workList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} 
			         else 
						{
							System.out
									.println("Nobody has made a donation, yet.");
						}*/
			         
				         break;
				     }
			
			case 4: {
				     System.out.println("--------Exited successfully--------"); 
				     System.exit(0);
			          break;
		        	}
		    }
		
		
	}
}

	
}