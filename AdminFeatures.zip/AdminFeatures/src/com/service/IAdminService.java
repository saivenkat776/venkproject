package com.service;

import java.util.List;

import com.bean.AdminBean;

public interface IAdminService 
{
	public String addDetails(AdminBean bean) ;
	public AdminBean viewDetails(int workid) ;
	public List<AdminBean> retriveAll();
}
