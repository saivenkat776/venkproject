package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.AdminBean;
import com.dao.AdminDAO;
import com.dao.IAdminDAO;

public class AdminService implements IAdminService
{
  AdminDAO dao=new AdminDAO();
  AdminBean bean=new AdminBean();
  List<AdminBean> workList=new ArrayList<AdminBean>();
	@Override
	public String addDetails(AdminBean bean)
	{ String seq;
	   seq=dao.addDetails(bean);	
		return seq;
	}

	@Override
	public AdminBean viewDetails(int workid)
	{
		dao.viewDetails(workid);
		return bean;
	}

	@Override
	public List<AdminBean> retriveAll()
	{
		dao.retriveAll();
		return workList;
	}

}
