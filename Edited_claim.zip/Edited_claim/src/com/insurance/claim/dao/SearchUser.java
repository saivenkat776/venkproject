package com.insurance.claim.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.insurance.claim.service.ISearchUser;

public class SearchUser implements ISearchUser {
    static  String value="";
	@Override
	public int searchUser(String user,String username) 
	
	{
		System.out.println("called dao");
		int updatecount=0;
		Connection con = null;
		  PreparedStatement pstmt = null;
		  ResultSet rs=null;
		  try {
			  
			  con=DB.getConnection(); 
			  System.out.println("is connected in search dao :"+con);
			  String ins_str ="select Username from Agent_User where Username='"+user+"' and Agentname='"+username+"'  " ;
			  System.out.println(ins_str);
			  pstmt = con.prepareStatement(ins_str);
		    	rs=pstmt.executeQuery();
			
			  while(rs.next())
			  {   value= rs.getString(1);
				  
			  }
			 // con.close();
			System.out.println("value from table :"+value);
			
			if(value.equals(user))
			  {
				
				System.out.println("entered if---");
				  updatecount=1;
			  System.out.println("updatecount"+updatecount);
			  return updatecount; 
			  }
			  else
			  {System.out.println("entered else---");
				  return updatecount;
			  }
			  
			  
		  }
		  catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
	
		
	}

}
