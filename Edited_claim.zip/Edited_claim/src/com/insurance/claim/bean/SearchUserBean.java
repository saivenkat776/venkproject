package com.insurance.claim.bean;

public class SearchUserBean {
	private String user;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

}
