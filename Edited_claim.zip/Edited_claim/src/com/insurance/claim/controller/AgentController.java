package com.insurance.claim.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.insurance.claim.service.ProfileCreationService;
import com.insurance.claim.service.SearchUserService;

public class AgentController extends HttpServlet
{
	public  void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
			   
			   {
		HttpSession session1=request.getSession(false); 
		
	 	
		String username=(String) session1.getAttribute("userName");
		System.out.println("user name in session :"+username);		
		
		
		
		SearchUserService usersearch=new SearchUserService();
		       RequestDispatcher rd = null;
		       String user="";
		       user=request.getParameter("user");
		       System.out.println("Searched user name is :"+user);
		       
		       int result=usersearch.searchUser(user,username);
		       if(result==1)
		       {
		    	   rd = request.getRequestDispatcher("/agent.jsp");
		       }
		       else
		       {
		    	   rd = request.getRequestDispatcher("/invalid.jsp");
		       }
		       rd.forward(request, response);
		       
			   }		   
}
