package com.insurance.claim.service;

public interface ISearchUser {
 
int searchUser(String user, String username);
}
