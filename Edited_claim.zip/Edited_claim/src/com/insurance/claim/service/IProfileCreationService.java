package com.insurance.claim.service;

import com.insurance.claim.bean.ProfileCreation;

public interface IProfileCreationService 
{
   int addProfile(String user,String pass,String role);
}
