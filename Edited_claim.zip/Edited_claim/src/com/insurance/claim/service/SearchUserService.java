package com.insurance.claim.service;

import com.insurance.claim.bean.ProfileCreation;
import com.insurance.claim.bean.SearchUserBean;
import com.insurance.claim.dao.SearchUser;

public class SearchUserService implements ISearchUser
{
	SearchUserBean sub = new SearchUserBean();
	
	
	
	@Override
	public int searchUser(String user, String username)
	{
		System.out.println("called service");
		SearchUser search=new SearchUser();
		sub.setUser(user);
		
		int updateResult = 0;
		 try
		 {
			 updateResult = search.searchUser(user, username);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
		
		
	}

}
