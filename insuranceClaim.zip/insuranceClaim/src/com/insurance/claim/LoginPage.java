package com.insurance.claim;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class LoginPage extends  HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		
		try {
			RequestDispatcher rd=null;
			Connection con=null;
			PreparedStatement pst=null;
			ResultSet rs=null;
			String str=null;
			
	     con=Connect.getconnect();
	   
		 String uname=request.getParameter("userName");
		 String password=request.getParameter("userPwd");
		 System.out.println(uname);
		 String sql="select Role_Code from User_Role where User_name=? and Password=?";
		 
			pst=con.prepareStatement(sql);
			pst.setString(1,uname);
			pst.setString(2,password);
			rs=pst.executeQuery();
		
		
		 while(rs.next())
		 {
			 str=rs.getString(1); 
		 }
		 
		 if(str.equals("Admin"))
		 {
			 request.getRequestDispatcher("/admin.jsp").include(request, response);
		 }
		 else if(str.equals("Agent"))
		 {
			 request.getRequestDispatcher("/agent.jsp").include(request, response);
		 }
		 else if(str.equals("Insured"))
		 {
			 request.getRequestDispatcher("/user.jsp").include(request, response);
		 }
		}
		 
		
			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
}
