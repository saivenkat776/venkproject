package com.loan.clientDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.loan.clientBean.clientBean;

//*********************** Final Entry ****************************************************

public class clientDAO 
{

	public void addLoanClient(clientBean cliBean)
	{
		      
			  Connection con = null;
			  PreparedStatement pstmt = null;
			  try
			  {
				  
				  con=Connect.getConnect();
				  System.out.println(con);
				  
				  String loansql ="insert into clientloan values(loan_id.nextval,?,?,?,?,?,?,?)";
				  
				  pstmt = con.prepareStatement(loansql);
				 
				  pstmt.setString(1,cliBean.getName());
				  pstmt.setString(2,cliBean.getEmail());
				  pstmt.setLong(3,cliBean.getMobile());
				  pstmt.setString(4,cliBean.getAddress());
				  pstmt.setDouble(5,cliBean.getIncome());
				  pstmt.setString(6,cliBean.getLoantype());
				  pstmt.setDouble(7,cliBean.getLoanamt());
				  
				  int updateCount = pstmt.executeUpdate();
				  con.close();
				  
				//  return updateCount;
				  
			  }
			  catch(Exception ex)
			  {
				  System.out.println(ex.toString());
				  //return 0;
			  }
		
	
	}
	
// ******************* Method for RETREIVING the LOAN ID ********************************
	
public int retriveloanid(clientBean cliBean)
	{ 
	      PreparedStatement pstmt = null;
		  Connection con = null;
		  ResultSet rs;
		  int loanid = 0;
		
	  String sql="select loan_id from clientloan where name=? ";
	 
	try {
		
// *************** Connecting to database *************************************************		
		
	      con=Connect.getConnect();
		  System.out.println(con);
		  
//*****************sql query to retreive **************************************************
		  
		  pstmt=con.prepareStatement(sql);
		  pstmt.setString(1,cliBean.getName());
		  rs = pstmt.executeQuery(sql);
		  
		  while(rs.next())
		   {
			   loanid=(rs.getInt(1));
		   }
		   System.out.println("loan applied successfull with loan_id : "+loanid+"\n");
		   con.close();
		   return loanid;
    	} 
	
	catch (SQLException e)
	{

		System.out.println(e);
	}
    	
	
	     
	  
	}

}
