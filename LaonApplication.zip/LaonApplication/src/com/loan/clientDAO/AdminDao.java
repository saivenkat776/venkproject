package com.loan.clientDAO;

import java.util.Scanner;

public class AdminDao 
{ 
	
  public static void main(String args[])
  {
	  Scanner sc=new Scanner(System.in);
	  Scanner sc1=new Scanner(System.in);
	  System.out.println("-----------------ADMIN LOGIN-----------------");
	  System.out.println("-> Enter username :");
	  String user=sc.nextLine();
	  System.out.println("-> Enter password :");
	  String pass=sc.nextLine();
	
	  if(user.equals("admin") && pass.equals("admin"))
	  {
		  System.out.println("Select the Operation To be Done :");
		  System.out.println("1.Insert \t\t 2.Update \t\t 3.Delete \t\t 4.Exit");
		  int ch=sc1.nextInt();
		  
		 while(ch>0)
		 {	 
		  switch(ch)
		  {
		  case 1:{
			 //      insert();
	              break;
		          }
		  case 2:{
			   //    update();
			       break;
		         }
		  case 3:{
			     //  delete();
			       break;
		          }
		  case 4:{
			       System.exit(0);
			       break;
		         }
		  default :System.out.println("enter valid choice !!!");
		  	  
		  }
		 }
	  }
	  else
	  {
		  System.out.println("--------------->> Invalid Credentials <<----------------");
	  }
	  
	  
  }
}
