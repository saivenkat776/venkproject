package com.loan.clientService;

import com.loan.clientBean.clientBean;
import com.loan.clientDAO.clientDAO;

//******************** ----->>>   Entry 2   <<<------- ****************************

public class clientService
{
	 public int addClientService(String name,String email,long mobile,String address,double income,String loantype,double loanamt)
	 {
		 
		    clientDAO cliDAO = new clientDAO();
		    
			clientBean cliBean = new clientBean();
			
//*************** SETTING VALUES into the Client Bean  *****************************			
			
			cliBean.setLoanamt(loanamt);
			cliBean.setLoantype(loantype);
			cliBean.setName(name);
			cliBean.setMobile(mobile);
			cliBean.setIncome(income);
			cliBean.setAddress(address);
			cliBean.setEmail(email); 

// *************** CALLING clientDAO to INSERT VALUES INTO DATABASE ***************
			
			
			int LoanID=0;
			 try
			 { 				
				 
//-------------->> to insert into database <<--------------------------------------				  
				 
				 cliDAO.addLoanClient(cliBean);
				  
//-------------->> to get THe LOAN ID from database <<--------------------------------------						  
				 
				 LoanID=cliDAO.retriveloanid(cliBean);
				
				 return LoanID;
			 }
			 
			 catch(Exception ex)
			 {
				 System.out.println(ex.toString());
				 return 0;
			 }
		 
		 
	 }

}
