package com.loan.clientcontrol;

import java.io.IOException;
import java.io.PrintWriter;

import com.loan.clientService.clientService;

// ---------->>>>>>>> ***********Entry 1*****************<<<<<--------------------------

public class clientControl 
{
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException 
   {
		RequestDispatcher rd = null;
		response.setContentType("text/html");
	  PrintWriter out=response.getWriter();
	
		String name="";
		String email="";
		String loantype="";
		long mobile=0;
		double income=0.00;
		String address="";
		double loanamt=0.00;
		
		
//***************  GEtting parameters******************************************************		
		
		loantype=request.getParameter("loantype");
		
		name=request.getParameter("uname");
		
		String mob=request.getParameter("mno");
		mobile=Long.parseLong(mob);
		
		String in=request.getParameter("income");
		income=Double.parseDouble(in);
		
		String lm=request.getParameter("loanamt");
		loanamt=Double.parseDouble(lm);
		
		address=request.getParameter("address");
		
		email=request.getParameter("email");
		
//******************** CALLING SERVICE method and passing values**************************		
		
		clientService cliService = new clientService();
		
int Loan_id = cliService.addClientService( name,email,mobile,address,income,loantype,loanamt);

		
		System.out.println("loan id is  :"+Loan_id);
		
		out.println("<h2>Loan form Submitted Successfull.</h2>");
		out.println("<h2>Loan Application_Id :</h2>"+Loan_id);
		
	/*	if (Loan_id!=0) {
			rd = request.getRequestDispatcher("/success.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}*/
		
		rd.forward(request, response);
			
   }
}


