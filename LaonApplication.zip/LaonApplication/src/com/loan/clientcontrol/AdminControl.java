package com.loan.clientcontrol;

import java.io.IOException;

import com.ram.controller.HttpServlet;
import com.ram.controller.HttpServletRequest;
import com.ram.controller.HttpServletResponse;
import com.ram.controller.RequestDispatcher;
import com.ram.controller.ServletException;
import com.ram.services.BookService;

public class AdminControl extends HttpServlet
{
	public  void doPost(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException 
			{
				RequestDispatcher rd = null;
				String user;
				String pass;
				
					 user=request.getParameter("username");
					
					
					 pass=request.getParameter("password");
					
					
					
										
					if (user.equals("admin")&&pass.equals("admin")) {
						rd = request.getRequestDispatcher("/success.jsp");
						
					} else {
						rd = request.getRequestDispatcher("/error.jsp");
					}
					rd.forward(request, response);
				}
					
					
					
			}
}
