package com.loan.clientBean;

import java.io.Serializable;

public class clientBean implements Serializable
{
	  private String loantype;
	  private double loanamt;
	  private String name;
	  private long mobile;
	  private double income;
	  private String address;
	  private String email;
	public String getLoantype() {
		return loantype;
	}
	public void setLoantype(String loantype) {
		this.loantype = loantype;
	}
	public double getLoanamt() {
		return loanamt;
	}
	public void setLoanamt(double loanamt) {
		this.loanamt = loanamt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public double getIncome() {
		return income;
	}
	public void setIncome(double income) {
		this.income = income;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	  
	  
	  
}