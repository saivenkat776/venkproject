package com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	public  static  Connection getConnection() 
	{
		Connection con = null;
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg602","training602");
			System.out.println("Connected...");
		}
		
		 catch (Exception e) 
		{
			
			e.printStackTrace();
		}

		return con;
			
	}
	
}
