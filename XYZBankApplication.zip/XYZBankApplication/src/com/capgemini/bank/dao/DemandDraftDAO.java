package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.util.DBConnection;

public class DemandDraftDAO implements IDemandDraftDAO
{

	@Override
	public int addDemandDraftDetails(DemandDraft demandBean) 
	{
		 Connection connection = DBConnection.getConnection();	
			
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			
			int transid;
			
			int queryResult=0;
			try
			{		
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
	        
				preparedStatement.setString(1,demandBean.getCustomername());
				preparedStatement.setString(2,demandBean.getPhonenumber());
				preparedStatement.setString(3,demandBean.getIn_favor_of());
				preparedStatement.setInt(4,demandBean.getDd_amount());
				preparedStatement.setInt(5,demandBean.getDd_commission());
				preparedStatement.setString(6,demandBean.getDescription());
				queryResult=preparedStatement.executeUpdate();
				if(queryResult==1)
				{
					System.out.println("Successfully inserted "+queryResult+" row ");
				}
				else
				{
					System.out.println("--------Unable to insert into DB-----------");
				}
			
				preparedStatement = connection.prepareStatement(QueryMapper.TRANSID_QUERY_SEQUENCE);
				resultSet=preparedStatement.executeQuery();

				if(resultSet.next())
				{
					transid=resultSet.getInt(1);
					System.out.println("Transaction  Id :"+transid);
				}
				return queryResult;
			}
			catch(SQLException sqlException)
			{
				sqlException.printStackTrace();
				return 0;
			}
			 
		
		
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException 
	{  Connection connection=DBConnection.getConnection();
	
	
	     PreparedStatement preparedStatement=null;
	       ResultSet resultset = null;
           	DemandDraft demandBean=null;
		
	
		preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DEMAND_DETAILS_QUERY);
		preparedStatement.setLong(1,transactionId);
		resultset=preparedStatement.executeQuery();
		
		if(resultset.next())
		{
			demandBean = new DemandDraft();
			
			demandBean.setDd_amount(resultset.getInt(1));
			demandBean.setDd_commission(resultset.getInt(2));
			demandBean.setDescription(resultset.getString(3));
			
			
			}

		return demandBean;
	}

	
}
