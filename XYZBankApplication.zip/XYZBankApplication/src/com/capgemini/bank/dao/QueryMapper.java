package com.capgemini.bank.dao;

public interface QueryMapper {
	
	
	public static final String VIEW_DEMAND_DETAILS_QUERY="SELECT dd_amount,dd_commission,description from   demand_draft WHERE transaction_id=?";
	public static final String INSERT_QUERY="INSERT INTO demand_draft VALUES(Transaction_Id_seq.NEXTVAL,?,?,?,SYSDATE,?,?,?)";
	public static final String TRANSID_QUERY_SEQUENCE="SELECT Transaction_Id_seq.CURRVAL FROM DUAL";
	
	
}
