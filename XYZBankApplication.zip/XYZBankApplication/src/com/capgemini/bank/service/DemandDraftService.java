package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;

import com.capgemini.patientapplication.exception.PatientException;

public class DemandDraftService
{


	DemandDraftDAO demandDao;
	
	
	public int addDemandDraftDetails(DemandDraft demandBean) throws PatientException {
		demandDao= new DemandDraftDAO();	
		int demandSeq;
		demandSeq= demandDao.addDemandDraftDetails(demandBean);
		return demandSeq; 
	}

	
	public DemandDraft getDemandDraftDetails(int transactionId) throws PatientException, SQLException {
		demandDao=new DemandDraftDAO();
		DemandDraft bean=null;
		bean=demandDao.getDemandDraftDetails(transactionId);
		return bean;
	}
}
