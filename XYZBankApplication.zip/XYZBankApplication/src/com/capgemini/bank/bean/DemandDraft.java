package com.capgemini.bank.bean;

import java.util.Date;

public class DemandDraft
{




	private String phonenumber;
	
	private String in_favor_of;
	
	private Date date_of_transaction;
	
	private String description;
	
	private int total;

	private int transactionid;
	
	private String customername;
	
	private int dd_amount;
	
	private int dd_commission;
	
	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}




	public void setCustomername(String customername) {
		this.customername = customername;
	}




	public void setDd_amount(int dd_amount) {
		this.dd_amount = dd_amount;
	}




	public void setDd_commission(int dd_commission)
	{if(dd_amount<=5000)
		
		{this.dd_commission =10;
	    }
	else
		if((dd_amount>5000)&&(dd_amount<=10000))
	{
		this.dd_commission =41;
	}
	else 
		if((dd_amount>10001)&&(dd_amount<=100000))
	{
		this.dd_commission =51;
	} 
	else
	{
		this.dd_commission =306;
	}
	}




	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}




	public void setIn_favor_of(String in_favor_of) {
		this.in_favor_of = in_favor_of;
	}




	public void setDate_of_transaction(Date date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}




	public void setDescription(String description) {
		this.description = description;
	}




	public int getTransactionid() {
		return transactionid;
	}




	public String getCustomername() {
		return customername;
	}




	public int getDd_amount() {
		return dd_amount;
	}




	public int getDd_commission() {
		return dd_commission;
	}




	public String getPhonenumber() {
		return phonenumber;
	}




	public String getIn_favor_of() {
		return in_favor_of;
	}




	public Date getDate_of_transaction() {
		return date_of_transaction;
	}




	public String getDescription() {
		return description;
	}


   

	


	public void setTotal(int total) {
		this.total = dd_amount+dd_commission;
	}




	public int getTotal() {
		return total;
	}




	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing client Details \n");
		sb.append("customer Name: " +customername +"\n");
		sb.append("DD amount : "+ dd_amount +"\n");
		sb.append("DD commisiion : "+ dd_commission +"\n");
		sb.append("Total : "+ total +"\n");
		sb.append("Remarks : "+ description +"\n");
	
		return sb.toString();
	}
	

	
}


