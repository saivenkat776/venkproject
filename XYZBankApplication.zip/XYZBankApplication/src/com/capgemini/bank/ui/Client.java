package com.capgemini.bank.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

import com.capgemini.patientapplication.exception.PatientException;


public class Client
{  static Scanner sc1 = new Scanner(System.in);
	static Scanner sc = new Scanner(System.in);
	static DemandDraftService demandService =new DemandDraftService();

	static Logger logger = Logger.getAnonymousLogger();
	
	public static void main(String[] args) throws PatientException {
	
		DemandDraft demandBean = new DemandDraft();

		int transactionid = 0;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  XYZ BANK APPLICATION");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter demand draft details ");
			System.out.println("2.Print Deamnd DRaft");
			
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					System.out.println("\n Enter Details");

					System.out.println("Enter customer name: ");
					demandBean.setCustomername(sc.next());

					System.out.println("Enter customer contact: ");
					demandBean.setPhonenumber(sc.next());

					System.out.println("In_Favor_Of : ");
					demandBean.setIn_favor_of(sc.next());

					System.out.println("Enter DD amount : ");

					try {
						demandBean.setDd_amount(sc1.nextInt());
					} 
					catch (InputMismatchException inputMismatchException) {
						sc.nextLine();
						System.err.println("Please enter a numeric value for age amount, try again");
						}


					System.out.println(" enter Remarks : ");
					demandBean.setDescription(sc.next());
					
	//calling enter method					
						transactionid = demandService.addDemandDraftDetails(demandBean);

						System.out.println("customer details  has been successfully registered ");
																			

					break;

		case 2:

					
					System.out.println("Enter numeric transaction id:");
					transactionid = sc1.nextInt();
								
					if (demandBean != null) {
						System.out.println("Name of the Bank : XYZ        :");
								
						System.out.println("DD amount  :"
								+ demandBean.getDd_amount());
						System.out.println("DD commission :"
								+ demandBean.getDd_commission());
						System.out.println("Total :         :"
								+ demandBean.getTotal());
						System.out.println("Remarks       :"
								+ demandBean.getDescription());
					} else {
						System.err
								.println("No details with id: "
										+ transactionid);
					}

					break;

			
		case 3:

					System.out.print("Exit  Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try
	

	
	
}
