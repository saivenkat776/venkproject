
CREATE TABLE demand_draft(transaction_id number,customer_name varchar2(20),in_favor_of varchar2(20),phonenumber varchar2(10),date_of_transaction DATE,dd_amount number,dd_commission number,description varchar2(50));


 CREATE SEQUENCE Transaction_Id_seq start with 10001;


